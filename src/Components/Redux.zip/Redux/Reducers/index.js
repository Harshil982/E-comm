import handleWishList from "./handleWishlist";
import { combineReducers } from 'redux'

const rootReducer = combineReducers({handleWishList})

export default rootReducer;